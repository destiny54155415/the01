package com.example.shopping_project.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    // 메인 페이지
    @GetMapping("/")
    public String home() {
        return "index";
    }

    // 로그인 페이지 (templates/member)
    @GetMapping("/login")
    public String login() {
        return "member/login";
    }

    // 회원가입 페이지 (templates/member)
    @GetMapping("/signup")
    public String signup() {
        return "member/signup";
    }
}
