상품 담당용 수정 (MemberController 수정 없음)

회원 로그인은 세션 키 "loginUser" 만 사용합니다.
기존 AdminProductController 는 loginRole/loginMember 만 봐서
회원 로그인 후 /admin/products 권한이 안 잡혔습니다.

덮어쓸 파일 (1개):
  src/main/java/com/example/shopping_project/controller/productcontroller/AdminProductController.java

적용:
1) Shopping_Project 루트에 이 zip 압축 해제
2) Rebuild / 재시작
3) destiny66 로그인 (role=ADMIN) 후 /admin/products 확인
   또는 /admin/dev-login
