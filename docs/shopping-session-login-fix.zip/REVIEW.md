# Shopping_Project 코드 검토 결과

업로드된 class / build.gradle 기준으로 검증했습니다.

## 확인된 문제

### 1) 로그인 세션 키 불일치 (치명)
- `MemberController.login` 성공 시 `loginUser`만 저장
- `AdminProductController.isAdmin`은 `loginRole` / `loginMember` / `adminDev`만 검사
- 결과: 회원 로그인해도 상품 관리자 페이지 권한이 안 잡힘 → `/admin/dev-login`으로만 접속되는 현상

### 2) 로그인 실패 메시지 키 불일치
- 컨트롤러: `model.addAttribute("error", ...)`
- 일부 템플릿: `${errorMessage}`
- 결과: 로그인 실패해도 화면에 에러가 안 보임

### 3) 관리자 role 값
- DB CHECK / 코드는 `ADMIN` (대문자)
- `"Admin"` 은 저장/비교 실패

### 4) build.gradle
- Spring Boot 4.1.2 + Java 25 + `spring-security-crypto` 구성은 정상
- 문제 없음

## 수정 파일 (이 zip)
1. `MemberController.java` — 로그인 시 loginUser/loginMember/loginRole/loginMemberName 동시 설정, error+errorMessage
2. `AdminProductController.java` — loginUser 역할도 관리자 판정에 포함
3. `member/login.html` — error / errorMessage 둘 다 표시

## 적용 방법
1. zip을 `Shopping_Project` 루트에 덮어쓰기
2. Rebuild / 재시작
3. Workbench:
```sql
USE petshop;
UPDATE members
SET password = '$2a$10$smu7CPUgH3O4iHi6g63SxeI4fkp91FFgo7t6ra71sXxzyLwQzANpS',
    role = 'ADMIN'
WHERE username = 'destiny66';
```
4. 로그인: destiny66 / 1234 → 헤더에 이름님, `/admin/products` 이동
