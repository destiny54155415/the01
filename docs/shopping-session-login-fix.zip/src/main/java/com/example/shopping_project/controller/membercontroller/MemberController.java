package com.example.shopping_project.controller.membercontroller;

import com.example.shopping_project.dto.memberdto.MemberJoinDto;
import com.example.shopping_project.dto.memberdto.MemberLoginDto;
import com.example.shopping_project.entity.memberentity.MemberEntity;
import com.example.shopping_project.service.memberservice.MemberService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 회원 로그인/회원가입 (세션 키 통일 수정본)
 *
 * 기존 문제:
 * - login 성공 시 loginUser 만 넣고 loginMember/loginRole/loginMemberName 미설정
 * - 상품 관리자(AdminProductController)는 loginRole/loginMember 를 보므로
 *   일반 로그인으로는 /admin/products 진입 불가
 * - 실패 메시지를 error 로만 넣어 errorMessage 템플릿과 불일치
 */
@Controller
public class MemberController {

    private final MemberService memberService;

    public MemberController(MemberService memberService) {
        this.memberService = memberService;
    }

    @GetMapping("/signup")
    public String signupForm() {
        return "member/signup";
    }

    @PostMapping("/signup")
    public String signup(MemberJoinDto dto, Model model) {
        try {
            memberService.join(dto);
        } catch (IllegalStateException e) {
            model.addAttribute("errorMessage", e.getMessage());
            return "member/signup";
        }
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginForm() {
        return "member/login";
    }

    @PostMapping("/login")
    public String login(MemberLoginDto dto, HttpSession session, Model model) {
        MemberEntity member = memberService.login(dto);
        if (member == null) {
            String msg = "아이디 또는 비밀번호가 올바르지 않습니다. 입력한 정보를 다시 확인해 주세요.";
            model.addAttribute("error", msg);
            model.addAttribute("errorMessage", msg);
            return "member/login";
        }
        bindLoginSession(session, member);
        if ("ADMIN".equalsIgnoreCase(safeRole(member))) {
            return "redirect:/admin/products";
        }
        return "redirect:/";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @GetMapping("/mypage")
    public String mypage(HttpSession session) {
        if (session.getAttribute("loginUser") == null) {
            return "redirect:/login";
        }
        return "member/mypage";
    }

    @PostMapping("/delete-member")
    public String deleteMember(HttpSession session) {
        MemberEntity loginUser = (MemberEntity) session.getAttribute("loginUser");
        if (loginUser != null) {
            memberService.deleteMember(loginUser.getUsername());
            session.invalidate();
        }
        return "redirect:/";
    }

    @GetMapping("/mypage/edit")
    public String editForm(HttpSession session, Model model) {
        MemberEntity loginUser = (MemberEntity) session.getAttribute("loginUser");
        if (loginUser == null) {
            return "redirect:/login";
        }
        model.addAttribute("member", loginUser);
        return "member/edit";
    }

    @PostMapping("/mypage/edit")
    public String updateMember(String password, String email, String phone,
                               String zipcode, String address, String addressDetail,
                               HttpSession session) {
        MemberEntity loginUser = (MemberEntity) session.getAttribute("loginUser");
        if (loginUser != null) {
            memberService.updateMember(
                    loginUser.getUsername(), password, email, phone, zipcode, address, addressDetail);
            MemberEntity updateUser = memberService.findByUsername(loginUser.getUsername());
            bindLoginSession(session, updateUser);
        }
        return "redirect:/mypage/member";
    }

    @GetMapping("/members/check-id")
    @ResponseBody
    public boolean checkId(@RequestParam("username") String username) {
        return memberService.checkUsernameDuplicate(username);
    }

    @GetMapping("/mypage/member")
    public String memberInfo(HttpSession session, Model model) {
        MemberEntity loginUser = (MemberEntity) session.getAttribute("loginUser");
        if (loginUser == null) {
            return "redirect:/login";
        }
        model.addAttribute("member", loginUser);
        return "member/member-info";
    }

    @GetMapping("/mypage/reviews")
    public String reviewManagement(HttpSession session) {
        if (session.getAttribute("loginUser") == null) {
            return "redirect:/login";
        }
        return "member/review-management";
    }

    @GetMapping("/mypage/wishlist")
    public String mypageWishlistForward() {
        return "forward:/wishlist";
    }

    @GetMapping("/mypage/order")
    public String orderList() {
        return "order/order-list";
    }

    private void bindLoginSession(HttpSession session, MemberEntity member) {
        String role = safeRole(member);
        session.setAttribute("loginUser", member);
        session.setAttribute("loginMember", member);
        session.setAttribute("loginMemberId", member.getId());
        session.setAttribute("loginUsername", member.getUsername());
        session.setAttribute("loginMemberName", member.getName());
        session.setAttribute("loginRole", role);
        if ("ADMIN".equalsIgnoreCase(role)) {
            session.setAttribute("adminDev", true);
        } else {
            session.removeAttribute("adminDev");
        }
    }

    private static String safeRole(MemberEntity member) {
        if (member == null || member.getRole() == null || member.getRole().isBlank()) {
            return "USER";
        }
        String role = member.getRole().trim().toUpperCase();
        if (role.startsWith("ROLE_")) {
            role = role.substring(5);
        }
        return role;
    }
}
