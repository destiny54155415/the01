package com.example.shopping_project.controller.productcontroller;

import com.example.shopping_project.dto.productdto.ProductDto;
import com.example.shopping_project.entity.productentity.PetType;
import com.example.shopping_project.entity.productentity.ProductEntity;
import com.example.shopping_project.service.productservice.CategoryService;
import com.example.shopping_project.service.productservice.ProductService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AdminProductController {
    private final ProductService productService;
    private final CategoryService categoryService;

    public AdminProductController(ProductService productService, CategoryService categoryService) {
        this.productService = productService;
        this.categoryService = categoryService;
    }

    @GetMapping(value={"/admin/products"})
    public String list(@RequestParam(required=false) String keyword, @RequestParam(required=false) Long categoryId, @RequestParam(required=false) PetType petType, @RequestParam(defaultValue="0") int page, HttpSession session, Model model) {
        if (!this.isAdmin(session)) {
            return "redirect:/login";
        }
        model.addAttribute("result", (Object)this.productService.searchAdmin(keyword, categoryId, petType, page));
        model.addAttribute("keyword", (Object)(keyword == null ? "" : keyword.trim()));
        model.addAttribute("categoryId", (Object)categoryId);
        model.addAttribute("petType", (Object)petType);
        model.addAttribute("petTypes", (Object)PetType.values());
        model.addAttribute("adminCategories", (Object)this.categoryService.findAllCategories());
        return "product/admin-list";
    }

    @GetMapping(value={"/admin/products/new"})
    public String createForm(HttpSession session, Model model) {
        if (!this.isAdmin(session)) {
            return "redirect:/login";
        }
        if (!model.containsAttribute("form")) {
            model.addAttribute("form", (Object)new ProductDto());
        }
        this.addFormOptions(model);
        return "product/admin-form";
    }

    @PostMapping(value={"/admin/products"})
    public String create(@Valid @ModelAttribute(value="form") ProductDto form, BindingResult bindingResult, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        if (!this.isAdmin(session)) {
            return "redirect:/login";
        }
        if (bindingResult.hasErrors()) {
            this.addFormOptions(model);
            return "product/admin-form";
        }
        this.productService.create(form);
        redirectAttributes.addFlashAttribute("message", (Object)"\uc0c1\ud488\uc744 \ub4f1\ub85d\ud588\uc2b5\ub2c8\ub2e4.");
        return "redirect:/admin/products";
    }

    @GetMapping(value={"/admin/products/{productId}/edit"})
    public String editForm(@PathVariable Long productId, HttpSession session, Model model) {
        if (!this.isAdmin(session)) {
            return "redirect:/login";
        }
        if (!model.containsAttribute("form")) {
            model.addAttribute("form", (Object)ProductDto.from((ProductEntity)this.productService.getProduct(productId)));
        }
        this.addFormOptions(model);
        return "product/admin-form";
    }

    @PostMapping(value={"/admin/products/{productId}"})
    public String update(@PathVariable Long productId, @Valid @ModelAttribute(value="form") ProductDto form, BindingResult bindingResult, HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        if (!this.isAdmin(session)) {
            return "redirect:/login";
        }
        form.setProductId(productId);
        if (bindingResult.hasErrors()) {
            this.addFormOptions(model);
            return "product/admin-form";
        }
        this.productService.update(productId, form);
        redirectAttributes.addFlashAttribute("message", (Object)"\uc0c1\ud488\uc744 \uc218\uc815\ud588\uc2b5\ub2c8\ub2e4.");
        return "redirect:/admin/products";
    }

    @PostMapping(value={"/admin/products/{productId}/deactivate"})
    public String deactivate(@PathVariable Long productId, HttpSession session, RedirectAttributes redirectAttributes) {
        if (!this.isAdmin(session)) {
            return "redirect:/login";
        }
        this.productService.deactivate(productId);
        redirectAttributes.addFlashAttribute("message", (Object)"\uc0c1\ud488\uc744 \ube44\ud65c\uc131\ud654\ud588\uc2b5\ub2c8\ub2e4.");
        return "redirect:/admin/products";
    }

    @PostMapping(value={"/admin/products/{productId}/delete"})
    public String delete(@PathVariable Long productId, HttpSession session, RedirectAttributes redirectAttributes) {
        if (!this.isAdmin(session)) {
            return "redirect:/login";
        }
        this.productService.delete(productId);
        redirectAttributes.addFlashAttribute("message", (Object)"\uc0c1\ud488\uc744 \uc0ad\uc81c\ud588\uc2b5\ub2c8\ub2e4.");
        return "redirect:/admin/products";
    }

    private void addFormOptions(Model model) {
        model.addAttribute("adminCategories", (Object)this.categoryService.findAllCategories());
        model.addAttribute("petTypes", (Object)PetType.values());
    }

    private boolean isAdmin(HttpSession session) {
        if (isAdminRole(session.getAttribute("loginRole"))) {
            return true;
        }
        // 회원 로그인은 loginUser 세션을 쓰므로 함께 검사
        if (hasAdminRole(session.getAttribute("loginMember"))
                || hasAdminRole(session.getAttribute("loginUser"))) {
            return true;
        }
        return Boolean.TRUE.equals(session.getAttribute("adminDev"));
    }

    private static boolean hasAdminRole(Object member) {
        if (member == null) {
            return false;
        }
        try {
            Object memberRole = member.getClass().getMethod("getRole").invoke(member);
            return isAdminRole(memberRole);
        } catch (ReflectiveOperationException ignored) {
            return false;
        }
    }

    private static boolean isAdminRole(Object role) {
        if (role == null) {
            return false;
        }
        String normalized = String.valueOf(role).trim().toUpperCase();
        if (normalized.startsWith("ROLE_")) {
            normalized = normalized.substring(5);
        }
        return "ADMIN".equals(normalized);
    }
}
