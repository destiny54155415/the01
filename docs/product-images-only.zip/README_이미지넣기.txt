이 폴더 안의 static 폴더를 지금 실행 중인 프로젝트에 복사하세요.

복사 위치:
  (프로젝트루트)/src/main/resources/static/

결과적으로 아래 파일이 있어야 합니다:
  src/main/resources/static/images/products/churu-tuna.jpg
  src/main/resources/static/css/common.css

복사 후 IntelliJ에서:
  1) Build > Rebuild Project
  2) 애플리케이션 중지 후 다시 Run
  3) 브라우저에서 Ctrl+F5 새로고침
  4) http://localhost:8080/images/products/churu-tuna.jpg 확인
