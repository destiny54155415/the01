package com.example.shopping_project.service.memberservice;

public class MemberService {
}
