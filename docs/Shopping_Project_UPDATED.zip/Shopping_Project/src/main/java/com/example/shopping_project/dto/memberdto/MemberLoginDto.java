package com.example.shopping_project.dto.memberdto;

public class MemberLoginDto {
}
