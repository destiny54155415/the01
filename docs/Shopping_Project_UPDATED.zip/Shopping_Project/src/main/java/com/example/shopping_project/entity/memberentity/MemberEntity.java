package com.example.shopping_project.entity.memberentity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@Table(name = "members") // DB 테이블명 매칭
@Entity
public class MemberEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "member_id") // DB 컬럼명 매칭
    private Long id;

    @Column(unique = true, nullable = false, length = 50) // 중복 값X, 빈 값X
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false, length = 50)
    private String name;

    @Column(unique = true, nullable = false, length = 100)
    private String email;

    @Column(length = 20)
    private String phone;

    public MemberEntity(String username, String password, String name, String email, String phone) {
      this.username = username;
      this.password = password;
      this.name = name;
      this.email = email;
      this.phone = phone;
    }
}
