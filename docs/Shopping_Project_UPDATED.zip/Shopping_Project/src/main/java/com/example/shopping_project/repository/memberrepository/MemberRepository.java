package com.example.shopping_project.repository.memberrepository;

public interface MemberRepository {
}
