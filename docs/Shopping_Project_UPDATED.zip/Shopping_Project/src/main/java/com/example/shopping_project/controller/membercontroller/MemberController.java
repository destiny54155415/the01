package com.example.shopping_project.controller.membercontroller;

public class MemberController {
}
