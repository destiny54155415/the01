고양이 용품 상품형(패키지) 실사 스타일 이미지 교체본

복사 위치:
  src/main/resources/static/images/

파일:
  food-cat.jpg
  food-pouch.jpg
  churu-tuna.jpg
  churu-salmon.jpg
  toy-wand.jpg
  toy-catnip.jpg
  house.jpg
  tofu-sand.jpg
  bentonite.jpg
  scoop.jpg

원본 브랜드 상표를 사용하지 않은 상품형 이미지입니다.
