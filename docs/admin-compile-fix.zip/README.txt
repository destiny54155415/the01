컴파일 오류 수정 (파일 위치 중요!)

1) 아래 파일을 각각 지정된 경로에 덮어쓰세요. 절대 한 파일에 합치지 마세요.

- src/main/java/com/example/shopping_project/controller/productcontroller/AdminDevController.java
  -> 클래스 이름: AdminDevController

- src/main/java/com/example/shopping_project/config/productconfig/GlobalModelAdvice.java
  -> 클래스 이름: GlobalModelAdvice
  (폴더가 productconfig 가 아니면 만들어 주세요)

- src/main/resources/templates/fragments/header.html

2) IntelliJ: Build > Rebuild Project
3) 브라우저: http://localhost:8080/admin/dev-login
   헤더에 "관리자님" / "로그아웃" 이 보이면 성공
